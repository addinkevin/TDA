#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include "MochilaAproximado/MainMochilaAproximado.h"
#include "ViajanteAproximado/MainViajanteAproximado.h"


using namespace std;

int main() {
    std::cout << "Running..." << std::endl;
    try {
        MainMochilaAproximado().run();
        MainViajanteAproximado().run();

    } catch(string error) {
        std::cout << "***ERROR***: "<< error << std::endl;
    }

    std::cout << "Fin." << std::endl;

    return 0;
}