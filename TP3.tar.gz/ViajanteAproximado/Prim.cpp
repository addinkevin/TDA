#include "Prim.h"
#include "PriorityQueue.h"

Prim::Prim(Graph* graph, int rootVertex) {
    this->graph = graph;
    this->rootVertex = rootVertex;
    this->mst = NULL;

}

Prim::~Prim() {
    if (this->mst != NULL) {
        delete this->mst;
    }
}

void Prim::calculateMST() {
    bool* proccesed = new bool[this->graph->getVertices()];
    Edge** parent = new Edge*[this->graph->getVertices()];

    for (int i = 0; i < this->graph->getVertices(); i++) {
        proccesed[i] = false;
        parent[i] = NULL;
    }

    PriorityQueue priorityQueue;
    priorityQueue.push(rootVertex,0);

    int verticesCount = 0;
    while (!priorityQueue.empty() && verticesCount < graph->getVertices()) {
        std::pair<int,double> pairObject = priorityQueue.pop();
        int currentVertex = pairObject.first;
        double priority = pairObject.second;

        if (proccesed[currentVertex]) continue;
        proccesed[currentVertex] = true;
        verticesCount += 1;

        std::list<Edge*>* adjList = this->graph->getAdjList(currentVertex);

        for (std::list<Edge*>::iterator it=adjList->begin(); it != adjList->end(); ++it){
            int nextVert = (*it)->getDest();
            double weight = (*it)->getWeight();

            if (!proccesed[nextVert] && (!parent[nextVert] || parent[nextVert]->getWeight() > weight)) {
                priorityQueue.push(nextVert, weight);
                parent[nextVert] = *it;
            }
        }
    }

    if (this->mst != NULL) {
        delete this->mst;
    }
    this->mst = new Graph(this->graph->getVertices());
    this->costMst = 0;


    for (int i = 0; i < this->graph->getVertices(); i++) {
        if (i == this->rootVertex) continue;
        this->mst->addEdge(parent[i]->getSource(), i, parent[i]->getWeight());
        this->costMst += parent[i]->getWeight();
    }

    delete[] proccesed;
    delete[] parent;

}

Graph *Prim::getMST() {
    return this->mst;
}

int Prim::getCostMST() {
    return this->costMst;
}


