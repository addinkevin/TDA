
#include "MapParserConstants.h"

std::string MapParserConstants::SOURCE_STRING = "Source";
std::string MapParserConstants::DESTINATION_STRING = "Dest";
std::string MapParserConstants::VISITED_STRING = "Visited";
std::string MapParserConstants::MAP_START_STRING = "Map";
std::string MapParserConstants::PATH_STRING = "Path";