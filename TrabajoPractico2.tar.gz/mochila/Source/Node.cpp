#include "../Headers/Node.h"

Node::Node(){
}

Node::~Node() {
}
