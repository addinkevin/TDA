#ifndef TDA_VIAJANTEAPROXIMADO_H
#define TDA_VIAJANTEAPROXIMADO_H

#include <vector>
#include "Graph.h"

using namespace std;

class ViajanteAproximado {
private:
    int initialVertex;
    vector< vector<int> >* matrix;


    Graph *createGraph();
    int calculateCost(vector<int>* path);
    vector<int> *createPreOrderWalk(Graph *graph, int vertex);
    void _preOrder(Graph *graph, int vertex, vector<int> *path, bool *marked);

public:
    ViajanteAproximado(vector< vector<int> >* matrix, int initialVertex);
    pair<int, vector<int>*> run();
};


#endif //TDA_VIAJANTEAPROXIMADO_H
