#include "ViajanteAproximado.h"
#include "Graph.h"
#include "Prim.h"

ViajanteAproximado::ViajanteAproximado(vector<vector<int> > *matrix, int initialVertex) {
    this->matrix = matrix;
    this->initialVertex = initialVertex;
}

pair<int, vector<int> *> ViajanteAproximado::run() {
    Graph* graph = this->createGraph();
    Prim* prim = new Prim(graph, this->initialVertex);
    prim->calculateMST();
    Graph* mst = prim->getMST();

    vector<int>* path = createPreOrderWalk(mst,this->initialVertex);
    delete graph;
    int cost = this->calculateCost(path);

    return pair<int, vector<int>*>(cost, path);
}


void ViajanteAproximado::_preOrder(Graph *graph, int vertex, vector<int> *path, bool *marked) {
    if (marked[vertex]) return;
    marked[vertex] = true;
    path->push_back(vertex);

    std::list<Edge*>* adjList = graph->getAdjList(vertex);
    for (std::list<Edge*>::iterator it=adjList->begin(); it != adjList->end(); ++it){
        int nextVert = (*it)->getDest();
        this->_preOrder(graph, nextVert, path, marked);
    }
}


Graph *ViajanteAproximado::createGraph() {
    Graph* graph = new Graph(this->matrix->size());

    // Precondición: La matriz es simetrica.
    for (int i = 0; i < this->matrix->size(); i++) {
        for (int j = i+1; j < this->matrix->size(); j++) {
            graph->addEdge(i,j,(int)(this->matrix->at(i).at(j)));
        }
    }

    return graph;
}



vector<int>* ViajanteAproximado::createPreOrderWalk(Graph *graph, int vertex) {
    vector<int>* path = new vector<int>();
    bool* marked = new bool[graph->getVertices()];
    for (int i = 0; i < graph->getVertices(); i++) {
        marked[i] = false;
    }

    this->_preOrder(graph, vertex, path, marked);

    path->push_back(vertex);

    delete marked;
    return path;
}

int ViajanteAproximado::calculateCost(vector<int>* path) {
    int cost = 0;
    for (unsigned int i = 0; i < path->size() - 1 ; i++) {
        int x = path->at(i);
        int y = path->at(i+1);
        cost += this->matrix->at(x).at(y);
    }

    return cost;
}