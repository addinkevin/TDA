#ifndef TRABAJOPRACTICO2_MAINVIAJANTE_H
#define TRABAJOPRACTICO2_MAINVIAJANTE_H

#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include "ParserTSPFile.h"
#include "TestPrim.h"
#include "ViajanteAproximado.h"

using namespace std;

class MainViajanteAproximado {
public:
    int calculateCost(vector<vector<int>>* matrixCost, vector<int>* list) {
        int cost = 0;
        for (unsigned int i = 0; i < list->size() - 1 ; i++) {
            int x = list->at(i);
            int y = list->at(i+1);
            cost += matrixCost->at(x).at(y);
        }

        return cost;
    }

    void _testExecutionTime(ofstream& output, string testName, string matrixFileName, string solutionFileName) {
        ParserTSPFile parserTSPFile(matrixFileName, solutionFileName);
        vector<vector<int>>* matrix = parserTSPFile.getMatrix();
        vector<int>* expectedList = parserTSPFile.getSolutionList();
        int expectedCost = calculateCost(matrix, expectedList);

        ViajanteAproximado* viajanteAproximado = new ViajanteAproximado(matrix, 0);
        clock_t start_time = clock();
        pair<int,vector<int>*> result = viajanteAproximado->run();
        clock_t stop_time = clock();


        int time = int((double(stop_time-start_time)/CLOCKS_PER_SEC)*1000);
        double errorRelativo = (abs(expectedCost-result.first)/double(expectedCost)) * 100;

        //"Test,Tiempo(ms),CostOptimo,CostAprox, Error"
        output << testName << "," << time << "," << expectedCost << "," << result.first << "," << errorRelativo << std::endl;

        delete result.second;
        delete matrix;
        delete expectedList;
        delete viajanteAproximado;
    }

    void testExecutionTime() {
        ofstream outputFile("./ViajanteAproximado/files/resultados.csv");

        outputFile << "Test,Tiempo(ms),CostOptimo,CostAprox,ErrorRelativo(%)" << std::endl;

        _testExecutionTime(outputFile, "tsp1(15nodos)", "./ViajanteAproximado/files/tsp1.txt", "./ViajanteAproximado/files/tsp1_s.txt");
        _testExecutionTime(outputFile, "tsp2(26nodos)", "./ViajanteAproximado/files/tsp2.txt", "./ViajanteAproximado/files/tsp2_s.txt");
        _testExecutionTime(outputFile, "tsp3(48nodos)", "./ViajanteAproximado/files/tsp3.txt", "./ViajanteAproximado/files/tsp3_s.txt");
        outputFile.close();
    }

    void run() {
        TestPrim().run();
        testExecutionTime();
    }
};


#endif //TRABAJOPRACTICO2_MAINVIAJANTE_H
