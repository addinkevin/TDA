#ifndef TDA_PRIM_H
#define TDA_PRIM_H


#include "Graph.h"

class Prim {
private:
    Graph* graph;
    int rootVertex;
    Graph* mst;
    int costMst;
public:
    Prim(Graph* graph, int rootVertex);
    ~Prim();

    void calculateMST();
    Graph* getMST();
    int getCostMST();
};


#endif //TDA_PRIM_H
