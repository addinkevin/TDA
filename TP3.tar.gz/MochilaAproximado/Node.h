#ifndef NODE_H_
#define NODE_H_

using namespace std;

class Node {

public:
	int valor;
	int weight;
	bool isInBag;

	Node();
	~Node();
};

#endif /* NODE_H_ */
