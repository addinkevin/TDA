#include "Mochila.h"
#include <math.h>
using namespace std;

Mochila::Mochila(Stage& stage, double e) {
    this->stage = stage;
    this->n = this->stage.qtyNode;
    this->w = this->stage.capacityBag;

    int maxV = this->calcularMaxV(this->stage);

    int n = this->stage.qtyNode;
    double b = (e/(2*n)) * maxV;

    for (int i = 0; i < this->stage.qtyNode; i++) {
        this->stage.getNode(i)->valor = static_cast<int>(ceil(this->stage.getNode(i)->valor / b));
    }

    this->v = this->calcularV();
    this->initMatrix();
}

Mochila::Mochila(Stage& stage) {
    this->stage = stage;
    this->n = this->stage.qtyNode;
    this->w = this->stage.capacityBag;
    this->v = this->calcularV();
    this->initMatrix();
}

void Mochila::initMatrix() {

	this->matrix = new int*[n+1];
	for(int i = 0; i < n+1; ++i) {
        matrix[i] = new int[v + 1];
	}


	for (int i = 0; i <= n; i++) {
		for(int j = 0; j <= v; j++) {
            matrix[i][j] = 0;
		}
	}
}

int Mochila::computarMochila(){
    int valuesSumWithOutCurrent = 0;

    for (int i = 1; i <= this->n; i++) {
        int weight = stage.getNode(i-1)->weight;
        int value = stage.getNode(i-1)->valor;
        for (int currentValue = 1; currentValue <= this->v; currentValue++) {
            if ( currentValue > valuesSumWithOutCurrent ) { // V > \sum_{j=1}^{i-1} v_j
                this->matrix[i][currentValue] = weight + this->matrix[i-1][max<int>(0, currentValue - value )];
            } else {
                this->matrix[i][currentValue] = min<int>(this->matrix[i-1][currentValue], weight + this->matrix[i-1][max<int>(0, currentValue - value)]);
            }
        }

        valuesSumWithOutCurrent += value;
    }

    int maxValue = 0;
    for (int i = 1; i < this->v; i++) {
        int matrixValue = this->matrix[this->n][i];
        if (matrixValue <= this->w && i > maxValue) {
            maxValue = i;
        }
    }

    this->solution = maxValue;

    return maxValue;

}

Mochila::~Mochila(){
	for(int i = 0; i < this->n+1; ++i) {
		delete [] matrix[i];
	}
	delete [] matrix;
}

int Mochila::getOptimo() {
    return this->stage.optimo;
}

int Mochila::calcularV() {
    int temp = 0;
    for (int i = 0; i < stage.qtyNode; i++) {
        temp += stage.getNode(i)->valor;
    }
    return temp;
}

int Mochila::calcularMaxV(Stage& stage) {
    int max = stage.getNode(0)->valor;
    for (int i = 1; i < stage.qtyNode; i++) {
        int value = stage.getNode(i)->valor;
        if (value > max) {
            max = value;
        }
    }
    return max;
}

vector<int> Mochila::getItemsInBag() {
    vector<int> itemsInBag;

    int value = this->solution;

    for (int i = this->n; i >= 1; i--) {
        if (this->matrix[i][value] != this->matrix[i-1][value]) {
            // Se incluyo el item ya que mejoro la solución
            itemsInBag.push_back(i);
            value = max(0,value - stage.getNode(i-1)->valor);
        }
    }

    return itemsInBag;
}

int Mochila::getMaxV() {
    return this->calcularMaxV(this->stage);
}



