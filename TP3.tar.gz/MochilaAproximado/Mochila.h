#ifndef MOCHILA_H_
#define MOCHILA_H_
#include "Parser.h"
#include "Stage.h"
#include "Node.h"
using namespace std;

class Mochila {
private:
	int** matrix;

	Stage stage;
	int n;
	int w;
	int v;
	int solution;

	int calcularV();
	void initMatrix();
	int calcularMaxV(Stage& stage);

public:
	Mochila(Stage& stage, double e);
    Mochila(Stage& stage);
	~Mochila();

	// Devuelve el valor aproximado obtenido.
	int computarMochila();

    int getOptimo();

    // Devuelve un vector de los elementos que van a la mochila.
    vector<int> getItemsInBag();

    int getMaxV();

};

#endif /* MOCHILA_H_ */
