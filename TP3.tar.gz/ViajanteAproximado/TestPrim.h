#ifndef TDA_TESTPRIM_H
#define TDA_TESTPRIM_H

#include "Graph.h"
#include "Prim.h"

class TestPrim {
public:
    TestPrim() {}
    ~TestPrim() {}

    void run() {
        Graph graph(4);
        graph.addEdge(0, 1, 1);
        graph.addEdge(1, 2, 2);
        graph.addEdge(2, 3, 4);
        graph.addEdge(3, 0, 3);

        Prim prim(&graph, 0);

        prim.calculateMST();
        if (prim.getCostMST() != 6) {
            throw std::string("Error en el test de Prim: Se obtuvo: ") + std::to_string(prim.getCostMST()) + " , se esperaba 6";
        }

        Graph graph2(4);
        graph2.addEdge(0,1,1);
        graph2.addEdge(1,2,1);
        graph2.addEdge(0,3,10);
        graph2.addEdge(1,3,100);
        graph2.addEdge(3,2,1000);

        Prim prim2(&graph2, 3);
        prim2.calculateMST();
        if (prim2.getCostMST() != 12) {
            throw std::string("Error en el test de Prim: Se obtuvo: ") + std::to_string(prim2.getCostMST()) + " , se esperaba 12";
        }
    }
};

#endif //TDA_TESTPRIM_H
