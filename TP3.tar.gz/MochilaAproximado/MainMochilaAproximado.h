#ifndef TRABAJOPRACTICO2_MAINMOCHILA_H
#define TRABAJOPRACTICO2_MAINMOCHILA_H
#include <iostream>
#include "Parser.h"
#include "Mochila.h"
#include <list>
#include <algorithm>
using namespace std;

class MainMochilaAproximado {
public:
    // Mochila test hard instances
    string rutaHard1= "./MochilaAproximado/files/knapPI_16_100_1000.csv";
    string rutaHard2 = "./MochilaAproximado/files/knapPI_16_500_1000.csv";
    string rutaHard3 = "./MochilaAproximado/files/knapPI_16_1000_1000.csv"; // Consume mucha memoria


    MainMochilaAproximado() {
    }

    void _runMochila(ofstream& output, Stage& stage, int instancia, double e) {
        clock_t start_time;
        clock_t stop_time;

        start_time = clock();
        Mochila* mochila = new Mochila(stage, e);
        int solutionRounded = mochila->computarMochila();
        stop_time = clock();

        vector<int> itemsInBag = mochila->getItemsInBag();
        int solution = 0;
        for (int j = 0; j < itemsInBag.size(); j++) {
            solution += stage.getNode(itemsInBag.at(j) - 1)->valor;
        }

        int optimo = mochila->getOptimo();
        int maxV = mochila->getMaxV();

        double errorRelativo = (abs(solution-optimo)/double(optimo)) * 100;

        int time = int((double(stop_time-start_time)/CLOCKS_PER_SEC)*1000);
        // "Instancia,Optimo,SolucionCalculada,SolucionRedondeada,e,maxVAjustado,ErrorRelativo,Tiempo"
        output << instancia << "," << optimo <<","<< solution << "," << solutionRounded << "," << e << "," << maxV << "," << errorRelativo << "," << time << std::endl;

        delete mochila;
    }

    void _testExecutionTime(string fileName) {
        Parser* parser = new Parser();
        vector<Stage>* lista = parser->getListOfStages(fileName);

        string outputFileName = fileName + "_results.csv";
        ofstream outputFile(outputFileName.c_str());
        outputFile << "Instancia,Optimo,SolucionCalculada,SolucionRedondeada,e,maxVAjustado,ErrorRelativo,Tiempo(ms)" << std::endl;

        for (int i = 0; i < lista->size(); i++) {
            Stage stage = lista->at(i);
            _runMochila(outputFile, stage, i, 0.8);
            _runMochila(outputFile, stage, i, 0.2);
        }

        outputFile.close();
        delete parser;
        delete lista;

    }

    void testExecutionTime() {
        _testExecutionTime(rutaHard1);
        _testExecutionTime(rutaHard2);
    }

    int run() {
        testExecutionTime();
    }

};


#endif //TRABAJOPRACTICO2_MAINMOCHILA_H
